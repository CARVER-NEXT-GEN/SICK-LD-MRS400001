echo "Running MRS1xxx scanner - modify launch file parameter for special settings."
../sick_generic_caller ./launch/sick_mrs_1xxx.launch

