#include "sick_scan/sick_scan_base.h" /* Base definitions included in all header files, added by add_sick_scan_base_header.py. Do not edit this line. */
#ifndef WSA_INIT_HPP
#define WSA_INIT_HPP

void wsa_init(void);

#endif // WSA_INIT_HPP
